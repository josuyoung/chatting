/**
 * 
 */
//function sendit(){
// 	let frm = document.joinForm;
// 	frm.submit();
// 	}

	function sendit(){
		var fromid = $("#userid").val();
		var toid = $("#toid").val();
		var contents = $("#contents").val();
		alert(fromid);
		$.ajax({
			type : "POST",
			url : "/write.chat",
			data : {
				"userid" : fromid,
				"toid" : toid,
				"contents" : contents
			},
			success: function(result){
				if(result.trim() == "1"){
					alert("전송에성공");
				}else if(result.trim() == "0"){
					alert("전송실패");
				}else{
					alert("데이터베이스오류");
				}
			}
			
		});
		$("#contents").val('');
		
	}
