package com.lemonmarket.web.servlet;

import java.io.IOException;

import com.lemonmarket.web.action.Action;
import com.lemonmarket.web.action.ActionForward;
import com.lemonmarket.web.dao.ChatDAO;
import com.lemonmarket.web.dto.ChatDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class chattingWriteOk implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {

		ActionForward forward = new ActionForward ();
		ChatDTO cdto = new ChatDTO();
		ChatDAO cdao = new ChatDAO();
		String userid = request.getParameter("userid");
		cdto.setFromId(userid);
		cdto.setToId(request.getParameter("toid"));
		cdto.setContents(request.getParameter("contents"));
		
		
		
		if(cdto.getToId() == null) {
			forward.setPath("index.jsp");
			forward.setRedirect(true);
		}else if(cdao.submit(cdto)){
			
			try {
				response.getWriter().write("1");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			forward.setPath("/getList.chat");
			forward.setRedirect(false);
			return forward;
			
			
		}
		
		return forward;
	
	}

}
