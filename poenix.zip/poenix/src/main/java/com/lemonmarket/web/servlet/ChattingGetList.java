package com.lemonmarket.web.servlet;

import java.util.List;

import com.lemonmarket.web.action.Action;
import com.lemonmarket.web.action.ActionForward;
import com.lemonmarket.web.dao.ChatDAO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ChattingGetList implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {

		ActionForward forward = new ActionForward();
		ChatDAO cdao = new ChatDAO();
		String userid = request.getParameter("userid");
		request.setAttribute("chatList", cdao.getList(userid));
		
		forward.setPath("/chatview.chat");
		forward.setRedirect(false);
		return forward;
		
	}

}
