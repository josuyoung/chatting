package com.lemonmarket.web.dto;

public class ChatDTO {

	
	// 변수 설정
	int chatId;
    private String fromId;
    private String toId;
    private String contents;
    private String chatTime;
    public int getChatId() {
    	return chatId;
    }
	public void setChatId(int chatId) {
		this.chatId = chatId;
	}
	public String getFromId() {
		return fromId;
	}
	public void setFromId(String fromId) {
		this.fromId = fromId;
	}
	public String getToId() {
		return toId;
	}
	public void setToId(String toId) {
		this.toId = toId;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getChatTime() {
		return chatTime;
	}
	public void setChatTime(String chatTime) {
		this.chatTime = chatTime;
	}
	
	
	// 게터 세터 추가
	

	
	
	
}
